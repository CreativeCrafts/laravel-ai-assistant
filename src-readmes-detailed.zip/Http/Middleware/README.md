# Http/Middleware

Middleware to secure or transform requests, e.g. signature checks.

## Classes in this directory
- **VerifyAiWebhookSignature** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Http\Middleware\VerifyAiWebhookSignature`
  - **Key methods:**
    - `public handle(Request $request, Closure $next): Response`

## When to Use & Examples
### VerifyAiWebhookSignature
**Use it when:**
- You need to secure inbound webhooks or validate requests.

**Example:**
```php
use Illuminate\Support\Facades\Route;

Route::post('/ai/webhooks', fn() => response()->noContent())
    ->middleware('verify.ai.webhook');
```
