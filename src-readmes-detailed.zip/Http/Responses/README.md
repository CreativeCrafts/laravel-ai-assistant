# Http/Responses

Response helpers like streaming (SSE).

## Classes in this directory
- **StreamedAiResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Http\Responses\StreamedAiResponse`
  - **Key methods:**
    - `public static fromGenerator(Generator $generator, int $heartbeatSeconds = 15): StreamedResponse`

## When to Use & Examples
### StreamedAiResponse
**Use it when:**
- You want to stream token-by-token output via SSE.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Facades\Ai;
use CreativeCrafts\LaravelAiAssistant\Http\Responses\StreamedAiResponse;

return StreamedAiResponse::fromGenerator(Ai::stream('Hello'));
```
