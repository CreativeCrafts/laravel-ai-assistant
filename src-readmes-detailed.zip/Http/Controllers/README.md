# Http/Controllers

Package controllers registered by routes or macros.

## Classes in this directory
- **HealthCheckController** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Http\Controllers\HealthCheckController`
  - **Key methods:**
    - `public __construct(private readonly HealthCheckService $healthCheckService)`
    - `public basic(Request $request): JsonResponse`
    - `public detailed(Request $request): JsonResponse`
    - `public ready(Request $request): JsonResponse`
    - `public live(Request $request): JsonResponse`

## When to Use & Examples
### HealthCheckController
**Use it when:**
- You are wiring a route to a packaged controller, commonly for streaming.

**Example:**
```php
use Illuminate\Support\Facades\Route;
use CreativeCrafts\LaravelAiAssistant\Http\Controllers\HealthCheckController;

Route::get('/ai/stream', HealthCheckController::class);
```
