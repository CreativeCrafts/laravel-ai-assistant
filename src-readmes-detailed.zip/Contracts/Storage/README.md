# Contracts/Storage

Interfaces that define public contracts you can type‑hint against.

## Classes in this directory
- **AssistantsStoreContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Contracts\Storage\AssistantsStoreContract`
  - **Key methods:**
    - `public put(array $assistant): void`
    - `public get(string $id): ?array`
    - `public all(): array`
    - `public delete(string $id): bool`
- **ConversationItemsStoreContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ConversationItemsStoreContract`
  - **Key methods:**
    - `public put(array $item): void`
    - `public get(string $id): ?array`
    - `public listByConversation(string $conversationId): array`
    - `public delete(string $id): bool`
- **ConversationsStoreContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ConversationsStoreContract`
  - **Key methods:**
    - `public put(array $conversation): void`
    - `public get(string $id): ?array`
    - `public all(): array`
    - `public delete(string $id): bool`
- **ResponsesStoreContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ResponsesStoreContract`
  - **Key methods:**
    - `public put(array $response): void`
    - `public get(string $id): ?array`
    - `public listByConversation(string $conversationId): array`
    - `public delete(string $id): bool`
- **ToolInvocationsStoreContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ToolInvocationsStoreContract`
  - **Key methods:**
    - `public put(array $invocation): void`
    - `public get(?string $id): ?array`
    - `public listByResponse(string $responseId): array`
    - `public delete(?string $id): bool`

## When to Use & Examples
### AssistantsStoreContract
**Use it when:**
- You want to type-hint interfaces for swapping implementations and testing.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Contracts\Storage\AssistantsStoreContract;

function handle(AssistantsStoreContract $dep) { /* ... */ }
```

### ConversationItemsStoreContract
**Use it when:**
- You want to type-hint interfaces for swapping implementations and testing.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ConversationItemsStoreContract;

function handle(ConversationItemsStoreContract $dep) { /* ... */ }
```

### ConversationsStoreContract
**Use it when:**
- You want to type-hint interfaces for swapping implementations and testing.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ConversationsStoreContract;

function handle(ConversationsStoreContract $dep) { /* ... */ }
```

### ResponsesStoreContract
**Use it when:**
- You want to type-hint interfaces for swapping implementations and testing.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ResponsesStoreContract;

function handle(ResponsesStoreContract $dep) { /* ... */ }
```

### ToolInvocationsStoreContract
**Use it when:**
- You want to type-hint interfaces for swapping implementations and testing.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Contracts\Storage\ToolInvocationsStoreContract;

function handle(ToolInvocationsStoreContract $dep) { /* ... */ }
```
