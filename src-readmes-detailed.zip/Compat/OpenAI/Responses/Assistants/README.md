# Compat/OpenAI/Responses/Assistants

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **AssistantResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Assistants\AssistantResponse`

## When to Use & Examples
### AssistantResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Assistants\AssistantResponse;
```
