# Compat/OpenAI/Responses/Meta

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **MetaInformation** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Meta\MetaInformation`
  - **Key methods:**
    - `private __construct(array $headers)`
    - `public static from(array $headers): self`
    - `public headers(): array`

## When to Use & Examples
### MetaInformation
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Meta\MetaInformation;
```
