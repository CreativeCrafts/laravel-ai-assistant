# Compat/OpenAI/Responses

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **StreamResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\StreamResponse`
  - **Key methods:**
    - `public getIterator(): Traversable`

## When to Use & Examples
### StreamResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\StreamResponse;
```
