# Compat/OpenAI/Responses/Completions

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **CreateResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Completions\CreateResponse`
- **StreamedCompletionResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Completions\StreamedCompletionResponse`

## When to Use & Examples
### CreateResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Completions\CreateResponse;
```

### StreamedCompletionResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Completions\StreamedCompletionResponse;
```
