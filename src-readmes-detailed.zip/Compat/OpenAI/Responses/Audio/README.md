# Compat/OpenAI/Responses/Audio

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **TranscriptionResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Audio\TranscriptionResponse`
- **TranslationResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Audio\TranslationResponse`

## When to Use & Examples
### TranscriptionResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Audio\TranscriptionResponse;
```

### TranslationResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Audio\TranslationResponse;
```
