# Compat/OpenAI/Responses/Threads/Runs

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **ThreadRunResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\Runs\ThreadRunResponse`

## When to Use & Examples
### ThreadRunResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\Runs\ThreadRunResponse;
```
