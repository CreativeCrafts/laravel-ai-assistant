# Compat/OpenAI/Responses/Threads

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **ThreadResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\ThreadResponse`
  - **Key methods:**
    - `private __construct()`
    - `public static from(array $attributes, MetaInformation $meta): self`
    - `public toArray(): array`

## When to Use & Examples
### ThreadResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\ThreadResponse;
```
