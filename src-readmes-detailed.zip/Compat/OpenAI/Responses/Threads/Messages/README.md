# Compat/OpenAI/Responses/Threads/Messages

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **ThreadMessageListResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\Messages\ThreadMessageListResponse`
  - **Key methods:**
    - `public __construct(array $data = [])`
    - `public toArray(): array`
- **ThreadMessageResponse** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\Messages\ThreadMessageResponse`
  - **Key methods:**
    - `private __construct()`
    - `public static from(array $attributes, MetaInformation $meta): self`
    - `public toArray(): array`

## When to Use & Examples
### ThreadMessageListResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\Messages\ThreadMessageListResponse;
```

### ThreadMessageResponse
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Responses\Threads\Messages\ThreadMessageResponse;
```
