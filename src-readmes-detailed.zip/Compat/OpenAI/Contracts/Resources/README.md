# Compat/OpenAI/Contracts/Resources

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **ThreadsContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Contracts\Resources\ThreadsContract`
  - **Key methods:**
    - `public create(array $parameters): ThreadResponse`
    - `public messages(): ThreadsMessagesContract`
    - `public runs(): ThreadsRunsContract`
- **ThreadsMessagesContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Contracts\Resources\ThreadsMessagesContract`
  - **Key methods:**
    - `public create(string $threadId, array $parameters): ThreadMessageResponse`
    - `public list(string $threadId): ThreadMessageListResponse`
- **ThreadsRunsContract** (interface) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Contracts\Resources\ThreadsRunsContract`
  - **Key methods:**
    - `public create(string $threadId, array $parameters): ThreadRunResponse`
    - `public retrieve(string $threadId, string $runId): ThreadRunResponse`

## When to Use & Examples
### ThreadsContract
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Contracts\Resources\ThreadsContract;
```

### ThreadsMessagesContract
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Contracts\Resources\ThreadsMessagesContract;
```

### ThreadsRunsContract
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Contracts\Resources\ThreadsRunsContract;
```
