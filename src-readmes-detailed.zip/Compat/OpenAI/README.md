# Compat/OpenAI

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **AssistantsResource** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\AssistantsResource`
  - **Key methods:**
    - `public create(array $parameters): AssistantResponse`
    - `public retrieve(string $assistantId): AssistantResponse`
- **Client** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Client`
  - **Key methods:**
    - `public __construct(?HttpClientInterface $http = null, // ignored, kept for BC private ?string $apiKey = null, private ?string $organizat...)`
    - `public assistants(): AssistantsResource`
    - `public threads(): ThreadsResource`
    - `public completions(): CompletionsResource`
    - `public chat(): ChatResource`
    - `public audio(): AudioResource`
- **CompletionsResource** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\CompletionsResource`
  - **Key methods:**
    - `public create(array $parameters): CompletionResponse`
    - `public createStreamed(array $parameters): iterable`
- **ThreadMessagesResource** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\ThreadMessagesResource`
  - **Key methods:**
    - `public create(string $threadId, array $parameters): ThreadMessageResponse`
    - `public list(string $threadId): ThreadMessageListResponse`
- **ThreadRunsResource** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\ThreadRunsResource`
  - **Key methods:**
    - `public create(string $threadId, array $parameters): ThreadRunResponse`
    - `public retrieve(string $threadId, string $runId): ThreadRunResponse`
- **ThreadsResource** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\ThreadsResource`
  - **Key methods:**
    - `public create(array $parameters): ThreadResponse`
    - `public messages(): ThreadMessagesResource`
    - `public runs(): ThreadRunsResource`

## When to Use & Examples
### AssistantsResource
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\AssistantsResource;
```

### Client
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Client;
```

### CompletionsResource
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\CompletionsResource;
```

### ThreadMessagesResource
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\ThreadMessagesResource;
```

### ThreadRunsResource
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\ThreadRunsResource;
```

### ThreadsResource
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\ThreadsResource;
```
