# Compat/OpenAI/Resources

OpenAI compatibility layer for SDK differences.

## Classes in this directory
- **Assistants** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Assistants`
  - **Key methods:**
    - `public create(array $parameters): AssistantResponse`
    - `public retrieve(string $assistantId): AssistantResponse`
- **Audio** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Audio`
  - **Key methods:**
    - `public transcribe(array $parameters): TranscriptionResponse`
    - `public translate(array $parameters): TranslationResponse`
- **Chat** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Chat`
  - **Key methods:**
    - `public create(array $parameters): CreateResponse`
    - `public createStreamed(array $parameters): StreamResponse`
- **Completions** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Completions`
  - **Key methods:**
    - `public create(array $parameters): CreateResponse`
    - `public createStreamed(array $parameters): StreamResponse`

## When to Use & Examples
### Assistants
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Assistants;
```

### Audio
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Audio;
```

### Chat
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Chat;
```

### Completions
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Compat\OpenAI\Resources\Completions;
```
