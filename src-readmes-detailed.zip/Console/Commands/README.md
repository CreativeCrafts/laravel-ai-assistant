# Console/Commands

Concrete Artisan commands available to your app.

## Classes in this directory
- **ConfigValidateCommand** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Console\Commands\ConfigValidateCommand`
  - **Key methods:**
    - `public handle(): int`
    - `private boolOption(mixed $value): bool`
    - `private validateConfiguration(): void`
    - `private addValidationResult(string $section, string $level, string $message): void`
    - `private outputJson(): void`
    - `private sanitizeConfigForDisplay(array $config): array`
    - `private outputReport(): void`
    - `private showConfigurationValues(): void`
    - `private validateEnvironmentVariables(): void`
    - `private getConfigKeyForEnvVar(string $envVar): string`
    - `private validateApiConfiguration(): void`
    - `private validateModelConfiguration(): void`
- **HealthCheckCommand** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Console\Commands\HealthCheckCommand`
  - **Key methods:**
    - `public handle(): int`
    - `private runDiagnostics(): void`
    - `private checkConfiguration(): void`
    - `private checkDependencies(): void`
    - `private checkDatabase(): void`
    - `private checkCache(): void`
    - `private checkOpenAiConnection(): void`
    - `private checkServices(): void`
    - `private checkPermissions(): void`
    - `private checkPerformance(): void`
    - `private addDiagnostic(string $category, string $level, mixed $message): void`
    - `private outputReport(): void`
- **InstallCommand** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Console\Commands\InstallCommand`
  - **Key methods:**
    - `public handle(): int`
    - `private static stringFromOption(mixed $value): string`
- **TestConnectionCommand** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Console\Commands\TestConnectionCommand`
  - **Key methods:**
    - `public handle(): int`
    - `private runConnectionTests(): void`
    - `private testBasicConfiguration(): void`
    - `private testApiAuthentication(): void`
    - `private testModelsEndpoint(): void`
    - `private testChatCompletion(): void`
    - `private testAssistantCreation(): void`
    - `private testNetworkConnectivity(): void`
    - `private testRateLimiting(): void`
    - `private testErrorHandling(): void`
    - `private addTestResult(string $testName, string $status, ?string $message = null, ?float $duration = null): void`
    - `private formatDuration(float $duration): string`

## When to Use & Examples
### ConfigValidateCommand
**Use it when:**
- You are running maintenance/setup tasks from the CLI.

**Example:**
```bash
php artisan ai:configvalidate --help
```

### HealthCheckCommand
**Use it when:**
- You are running maintenance/setup tasks from the CLI.

**Example:**
```bash
php artisan ai:healthcheck --help
```

### InstallCommand
**Use it when:**
- You are running maintenance/setup tasks from the CLI.

**Example:**
```bash
php artisan ai:install --help
```

### TestConnectionCommand
**Use it when:**
- You are running maintenance/setup tasks from the CLI.

**Example:**
```bash
php artisan ai:testconnection --help
```
