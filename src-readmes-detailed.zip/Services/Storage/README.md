# Services/Storage

Application‑level services orchestrating flows and domain logic.

## Classes in this directory
- **EloquentAssistantsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentAssistantsStore`
  - **Key methods:**
    - `public put(array $assistant): void`
    - `public get(string $id): ?array`
    - `public all(): array`
    - `public delete(string $id): bool`
- **EloquentConversationItemsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentConversationItemsStore`
  - **Key methods:**
    - `public put(array $item): void`
    - `public listByConversation(string $conversationId): array`
    - `public get(string $id): ?array`
    - `public delete(string $id): bool`
    - `private convertModelIdToString(mixed $modelId): string`
- **EloquentConversationsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentConversationsStore`
  - **Key methods:**
    - `public put(array $conversation): void`
    - `public all(): array`
    - `public get(string $id): ?array`
    - `public delete(string $id): bool`
    - `private convertModelIdToString(mixed $modelId): string`
- **EloquentResponsesStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentResponsesStore`
  - **Key methods:**
    - `public put(array $response): void`
    - `public listByConversation(string $conversationId): array`
    - `public get(string $id): ?array`
    - `public delete(string $id): bool`
    - `private convertModelIdToString(mixed $modelId): string`
- **EloquentToolInvocationsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentToolInvocationsStore`
  - **Key methods:**
    - `public put(array $invocation): void`
    - `public listByResponse(string $responseId): array`
    - `public get(?string $id): ?array`
    - `public delete(?string $id): bool`
    - `private generateId(): string`
    - `private convertModelIdToString(mixed $modelId): string`
- **InMemoryAssistantsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryAssistantsStore`
  - **Key methods:**
    - `public put(array $assistant): void`
    - `public get(string $id): ?array`
    - `public all(): array`
    - `public delete(string $id): bool`
- **InMemoryConversationItemsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryConversationItemsStore`
  - **Key methods:**
    - `public put(array $item): void`
    - `public get(string $id): ?array`
    - `public listByConversation(string $conversationId): array`
    - `public delete(string $id): bool`
- **InMemoryConversationsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryConversationsStore`
  - **Key methods:**
    - `public put(array $conversation): void`
    - `public get(string $id): ?array`
    - `public all(): array`
    - `public delete(string $id): bool`
- **InMemoryResponsesStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryResponsesStore`
  - **Key methods:**
    - `public put(array $response): void`
    - `public get(string $id): ?array`
    - `public listByConversation(string $conversationId): array`
    - `public delete(string $id): bool`
- **InMemoryToolInvocationsStore** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryToolInvocationsStore`
  - **Key methods:**
    - `public put(array $invocation): void`
    - `public get(?string $id): ?array`
    - `public listByResponse(string $responseId): array`
    - `public delete(?string $id): bool`
    - `private generateId(): string`

## When to Use & Examples
### EloquentAssistantsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentAssistantsStore;

$svc = app(EloquentAssistantsStore::class);
$dto = $svc->quick('Explain queues.');
```

### EloquentConversationItemsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentConversationItemsStore;

$svc = app(EloquentConversationItemsStore::class);
$dto = $svc->quick('Explain queues.');
```

### EloquentConversationsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentConversationsStore;

$svc = app(EloquentConversationsStore::class);
$dto = $svc->quick('Explain queues.');
```

### EloquentResponsesStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentResponsesStore;

$svc = app(EloquentResponsesStore::class);
$dto = $svc->quick('Explain queues.');
```

### EloquentToolInvocationsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\EloquentToolInvocationsStore;

$svc = app(EloquentToolInvocationsStore::class);
$dto = $svc->quick('Explain queues.');
```

### InMemoryAssistantsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryAssistantsStore;

$svc = app(InMemoryAssistantsStore::class);
$dto = $svc->quick('Explain queues.');
```

### InMemoryConversationItemsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryConversationItemsStore;

$svc = app(InMemoryConversationItemsStore::class);
$dto = $svc->quick('Explain queues.');
```

### InMemoryConversationsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryConversationsStore;

$svc = app(InMemoryConversationsStore::class);
$dto = $svc->quick('Explain queues.');
```

### InMemoryResponsesStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryResponsesStore;

$svc = app(InMemoryResponsesStore::class);
$dto = $svc->quick('Explain queues.');
```

### InMemoryToolInvocationsStore
**Use it when:**
- You need orchestration/business logic on top of chat and repository layers.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Services\Storage\InMemoryToolInvocationsStore;

$svc = app(InMemoryToolInvocationsStore::class);
$dto = $svc->quick('Explain queues.');
```
