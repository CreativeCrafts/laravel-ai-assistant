# Repositories/Http

High‑level API wrappers coordinating SDK calls with retries.

## Classes in this directory

## When to Use & Examples