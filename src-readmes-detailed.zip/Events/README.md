# Events

Components grouped by responsibility.

## Classes in this directory

## When to Use & Examples