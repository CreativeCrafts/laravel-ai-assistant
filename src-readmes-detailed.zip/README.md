# .

Components grouped by responsibility.

## Classes in this directory
- **AiAssistant** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\AiAssistant`
  - **Key methods:**
    - `public __construct(protected string $prompt = '')`
    - `public static acceptPrompt(string $prompt): self`
    - `public static init(?AssistantService $client = null): self`
    - `public client(AssistantService $client): self`
    - `public withAutoReset(bool $enabled): self`
    - `public useConversation(string $conversationId): self`
    - `public setSystemMessage(string $message): self`
    - `public instructions(string $systemOrPersona): self`
    - `public setDeveloperMessage(string $message): self`
    - `public setModelName(string $model): self`
    - `public includeFileSearchTool(array $vectorStoreIds = []): self`
    - `public useFileSearch(bool $enabled = true): self`
- **Assistant** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\Assistant`
  - **Key methods:**
    - `public static new(): Assistant`
    - `public client(AssistantService $client): Assistant`
    - `public setModelName(string $modelName): Assistant`
    - `public adjustTemperature(int|float $temperature): Assistant`
    - `public setAssistantName(string $assistantName = ''): Assistant`
    - `public setAssistantDescription(string $assistantDescription = ''): Assistant`
    - `public setInstructions(string $instructions = ''): Assistant`
    - `public includeCodeInterpreterTool(array $fileIds = []): Assistant`
    - `public includeFileSearchTool(array $vectorStoreIds = []): Assistant`
    - `public includeFunctionCallTool(string $functionName, string $functionDescription = '', FunctionCallParameterContract|array $functionParameters = [],...): Assistant`
    - `public create(): NewAssistantResponseData`
    - `public assignAssistant(?string $assistantId = null): Assistant`
- **LaravelAiAssistantServiceProvider** (class) — *Package component.*  
  FQCN: `CreativeCrafts\LaravelAiAssistant\LaravelAiAssistantServiceProvider`
  - **Key methods:**
    - `public configurePackage(Package $package): void`
    - `public packageRegistered(): void`
    - `public packageBooted(): void`
    - `protected applyEnvironmentOverlayDefaults(): void`
    - `protected loadPackageBaseConfig(): array`
    - `protected arrayReplaceRecursive(array $base, array $replacements): array`
    - `protected arrayRecursiveDiff(array $a, array $b): array`
    - `protected shouldSkipValidation(): bool`
    - `protected validateConfiguration(): void`
    - `protected validateRequiredSettings(array $config): void`
    - `protected isTestApiKey(string $apiKey): bool`
    - `protected validateModelConfiguration(array $config): void`

## When to Use & Examples
### AiAssistant
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\AiAssistant;
```

### Assistant
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\Assistant;
```

### LaravelAiAssistantServiceProvider
**Use it when:**
- General use for this area.

**Example:**
```php
use CreativeCrafts\LaravelAiAssistant\LaravelAiAssistantServiceProvider;
```
